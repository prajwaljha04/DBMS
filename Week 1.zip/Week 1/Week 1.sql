show databases;
create database newdatabase;
use newdatabase;
create table uno
(
name varchar(2)
);

create table student(
	stdid INT ,stdname varchar(20),
    dob date,
    doj date,
    fee int,
    gender varchar(50)
);

DESC student;

insert INTO student values
(1,'SHAREEF','2001-01-10','2001-10-05',1000,'M'),
(2,'NADEEM','2001-10-05','2001-10-25',1100,'M');

alter table student add phone_no int;

alter table student
rename column phone_no to student_no;

select * from student;

delete from student where STDID=2;